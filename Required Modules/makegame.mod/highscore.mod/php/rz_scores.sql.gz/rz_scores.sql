-- phpMyAdmin SQL Dump
-- version 2.8.2.4
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Erstellungszeit: 05. September 2007 um 12:24
-- Server Version: 4.1.15
-- PHP-Version: 5.1.6-1
-- 
-- Datenbank: `highscore`
-- 

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `rz_scores`
-- 

CREATE TABLE `rz_scores` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `datum` datetime NOT NULL default '0000-00-00 00:00:00',
  `user` varchar(128) NOT NULL default '',
  `ip` varchar(64) NOT NULL default '',
  `score` int(10) unsigned NOT NULL default '0',
  `version` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Daten für Tabelle `rz_scores`
-- 

